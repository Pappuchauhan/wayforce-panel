import{j as t,d as a}from"./index-Lpbe05IJ.js";const o=({label:s})=>t.jsx(a.Label,{className:"col-span-4 sm:col-span-2 font-medium text-sm",children:s});export{o as L};
