import{j as s}from"./index-tXNXoeRs.js";const r=({errorName:t})=>s.jsx(s.Fragment,{children:t&&s.jsx("span",{className:"text-red-400 text-sm mt-2",children:t.message})});export{r as E};
